import React, { PureComponent } from 'react'

export class Error extends PureComponent {
  render() {
    return (
      <div>
        <h2>A donde vas?</h2>
        <h3>Pagina no encontrada</h3>
      </div>
    )
  }
}

export default Error