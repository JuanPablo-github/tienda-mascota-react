

function Nosotros () {

    return (
      <div >
        <h2>Nosotros</h2>

        <p>Somos un equipo apasionado por la tecnología y el desarrollo web. Nuestro objetivo es crear experiencias únicas y funcionales para nuestros usuarios.</p>
        
      </div>
    )
  }


export default Nosotros