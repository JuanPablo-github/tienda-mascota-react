import { useParams } from "react-router-dom";
import productosMascotas from "./productosMascotas";
import "./Detalle.css"; // Asegúrate de crear este archivo

function Detalle() {
  const { id } = useParams();
  const producto = productosMascotas.find((prod) => prod.id === parseInt(id));

  if (!producto) return <h2>Producto no encontrado</h2>;

  return (
    <div className="detalle-container">
      <div className="detalle-card">
        <img src={producto.imagen} alt={producto.nombre} className="detalle-imagen" />

        <div className="detalle-info">
          <h2>{producto.nombre}</h2>
          <p className="detalle-id">ID: #{producto.id}</p>
          <p>{producto.descripcion}</p>
          <h3>${producto.precio}</h3>

          <div className="detalle-controles">
            <label>
              Cantidad:
              <input type="number" min="1" defaultValue="1" className="cantidad-input" />
            </label>

            <button className="btn-agregar">
              Agregar al carrito 🛒
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Detalle;
