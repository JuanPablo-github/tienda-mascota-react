import NavBar from './NavBar';
import { Outlet } from 'react-router-dom';

function Layout() {
  return (
    <>

      <NavBar />
      <main className="main-content">
        <Outlet />
      </main>
      
    </>
  );
}


export default Layout